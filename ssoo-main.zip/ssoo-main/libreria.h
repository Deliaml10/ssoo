#ifndef _LIBRERIA_H
#define _LIBRERIA_H
int head(int entrada);
int tail(int entrada);
int longlines(int entrada);
#endif


